# -*- coding: utf-8 -*-
"""
demo_app.py - TrajRL 结果向演示应用 (Streamlit)

一期功能 (结果向):
  * 行程时间预测 TTE : 基于距离的线性基线, 展示"路径 -> 预测时长"
  * 相似路径检索     : KNN 检索最相似的轨迹, 地图叠加展示

口径声明:
  * Porto 原始 CSV 无行程时长真值, 本 demo 的时长标签为预处理阶段
    按 15s 均匀采样推断的 elapsed_inferred, 界面已明确标注"推断值"。
  * 不做任何论文 SOTA 精度承诺, 仅用于展示与交互。

架构预留:
  * 页面通过 PAGES 字典注册, 后续增加"原理向"展示 (双视图增强 /
    多尺度时空可视化) 时, 新增一个 key 并实现 render_xxx() 即可,
    导航与布局自动接入。

运行:
    streamlit run demo_app.py
"""

import os
import sys

# 保证可从任意工作目录 import 同目录模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import random

import plotly.graph_objects as go
import streamlit as st

from demo_data import (
    SAMPLE_PATH,
    PortoCorpus,
    display_points,
    load_records,
)

st.set_page_config(page_title="TrajRL 结果向 Demo", page_icon="🚕", layout="wide")

# ------------------------------------------------------------ data loading
@st.cache_resource
def get_corpus():
    recs = load_records(SAMPLE_PATH)
    return PortoCorpus(recs)


@st.cache_data
def cached_pick_index(seed):
    """按 seed 挑一条轨迹索引, 保证 button 换轨迹时每次不同."""
    corpus = get_corpus()
    return seed % len(corpus.records)


def pick_record(corpus, seed):
    return corpus.records[seed % len(corpus.records)]


# -------------------------------------------------------------- widgets
def render_tte_page(corpus):
    st.subheader("行程时间预测 (Travel Time Estimation)")
    st.caption("根据一条轨迹的空间距离, 用演示基线模型预测行程时长。")

    c1, c2 = st.columns([3, 2])
    with c2:
        seed = st.slider("抽样种子 (换一条轨迹)", 0, 9999, 42, 1)
        rec = pick_record(corpus, seed)
        st.markdown(
            f"**当前轨迹** `{rec['trip_id']}` · 出租车 `{rec['taxi_id']}`"
        )

        # ---- 预测
        pred_s, pred_min = corpus.predict_tte(rec["cum_dist"])
        actual_s = float(rec["elapsed_inferred"])
        actual_min = actual_s / 60.0
        m1, m2, m3 = st.columns(3)
        m1.metric("行程距离", f"{rec['cum_dist']/1000:.2f} km")
        m2.metric("模型预测", f"{pred_min:.1f} min")
        m3.metric("推断时长(标签)", f"{actual_min:.1f} min")
        st.caption(
            f"点位数 {rec['n_points']} · 起终点直线 {rec['cum_dist']/1000:.2f} km"
        )

        # ---- 基线说明
        st.info(
            "**预测口径**：线性基线 `时长 = %.4f × 距离 + %.1f 秒`，"
            "拟合于本 demo 的 1 万条样本，R²=%.2f，MAE≈%.0f 秒。\n\n"
            "**标签口径**：Porto 原始数据无行程时长真值，"
            "`推断时长` 为预处理按 15s 均匀采样推断的**近似值**，"
            "仅用于演示，不代表论文指标。"
            % (
                corpus.a,
                corpus.b,
                corpus.tte_stats["r2"],
                corpus.tte_stats["mae_s"],
            )
        )

    with c1:
        fig = build_traj_figure(rec, color="#2563EB", name="当前轨迹")
        st.plotly_chart(fig, width="stretch")

    # ---- 全体样本: 距离 vs 时长 散点 + 基线
    st.markdown("#### 全样本：距离 vs 推断时长（基线拟合）")
    fig2 = go.Figure()
    fig2.add_trace(
        go.Scattergl(
            x=corpus.cum_dist / 1000.0,
            y=corpus.elapsed / 60.0,
            mode="markers",
            marker=dict(size=3, color="#94A3B8", opacity=0.5),
            name="样本轨迹",
        )
    )
    xs = [0.0, float(corpus.cum_dist.max()) / 1000.0]
    fig2.add_trace(
        go.Scatter(
            x=xs,
            y=[(corpus.a * x * 1000 + corpus.b) / 60.0 for x in xs],
            mode="lines",
            line=dict(color="#DC2626", width=3),
            name="预测基线",
        )
    )
    fig2.update_layout(
        height=380,
        xaxis_title="行程距离 (km)",
        yaxis_title="推断时长 (min)",
        legend=dict(orientation="h", y=1.08),
    )
    st.plotly_chart(fig2, width="stretch")

    # ---- 自定义输入
    st.markdown("#### 自定义输入：给定距离预测时长")
    km = st.number_input("行程距离 (km)", 0.5, 100.0, 5.0, 0.5)
    ps, pm = corpus.predict_tte(km * 1000.0)
    st.markdown(f"> **预测时长 ≈ {pm:.1f} 分钟**（{ps:.0f} 秒）· 仅基于距离的近似演示")


def render_retrieval_page(corpus):
    st.subheader("相似路径检索 (Similar Trajectory Search)")
    st.caption(
        "从 1 万条 Porto 轨迹中，用特征向量（48 维，重采样 24 点环状等距）"
        "KNN 检索与所选轨迹最相似的路径。"
    )

    c1, c3 = st.columns([3, 1])
    with c3:
        seed = st.slider("抽样种子 (换一条轨迹)", 0, 9999, 123, 1, key="retr_seed")
        k = st.slider("返回相似轨迹数 Top-K", 3, 10, 5, 1)
        rec = pick_record(corpus, seed)
        st.markdown(f"**查询轨迹** `{rec['trip_id']}`")

    hits = corpus.search(rec, k=k)

    with c1:
        fig = build_traj_figure(rec, color="#18212B", name="查询轨迹", width=3)
        palette = ["#2563EB", "#0F766E", "#D97706", "#DC2626", "#7C3AED",
                   "#0891B2", "#65A30D", "#DB2777", "#4F46E5", "#EA580C"]
        for i, (hrec, d) in enumerate(hits):
            color = palette[i % len(palette)]
            fig.add_trace(
                go.Scatter(
                    x=[p[0] for p in display_points(hrec)],
                    y=[p[1] for p in display_points(hrec)],
                    mode="lines",
                    line=dict(color=color, width=1.6),
                    opacity=0.8,
                    name=f"#{i+1} {hrec['trip_id'][-6:]}",
                )
            )
        st.plotly_chart(fig, width="stretch")

    # 结果表
    rows = []
    for i, (hrec, d) in enumerate(hits):
        rows.append(
            {
                "排名": f"#{i+1}",
                "轨迹 ID": hrec["trip_id"],
                "平均点偏移 (m)": round(d / (corpus.n_sig ** 0.5), 1),
                "距离 (km)": round(hrec["cum_dist"] / 1000.0, 2),
                "推断时长 (min)": round(hrec["elapsed_inferred"] / 60.0, 1),
                "点数": hrec["n_points"],
            }
        )
    if rows:
        st.dataframe(rows, width="stretch", hide_index=True)
    st.caption(
        "相似度 = 特征向量欧氏距离在 24 个重采样点上的平均空间偏移（米）；"
        "越小表示路径在空间上越接近。"
    )


# -------------------------------------------------------------- helpers
def build_traj_figure(rec, color="#2563EB", name="轨迹", width=2.5):
    pts = display_points(rec)
    lon = [p[0] for p in pts]
    lat = [p[1] for p in pts]
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=lon,
            y=lat,
            mode="lines",
            line=dict(color=color, width=width),
            name=name,
            opacity=0.9,
        )
    )
    fig.add_trace(
        go.Scatter(
            x=[lon[0], lon[-1]],
            y=[lat[0], lat[-1]],
            mode="markers",
            marker=dict(size=[9, 9], color=[color, "#DC2626"], symbol=["circle", "x"]),
            name="起/终点",
        )
    )
    fig.update_layout(
        height=520,
        margin=dict(l=10, r=10, t=30, b=10),
        xaxis_title="经度",
        yaxis_title="纬度",
        legend=dict(orientation="h", y=1.06),
    )
    fig.update_yaxes(scaleanchor="x", scaleratio=1)  # 经纬度等比例
    return fig


# ---------------------------------------------------------------- pages
PAGES = {
    "一、行程时间预测 (TTE)": render_tte_page,
    "二、相似路径检索": render_retrieval_page,
    # 预留: 三、原理向展示 (双视图增强 / 多尺度时空)  -> 下一期实现
}

def main():
    st.title("TrajRL 结果向演示")
    st.caption(
        "数据：Porto 出租车轨迹抽样 10,000 条 | "
        "时长标签为 15s 均匀推断近似值（非真值）| 仅作演示，不承诺论文精度"
    )

    corpus = get_corpus()

    page_name = st.sidebar.radio("功能", list(PAGES.keys()))
    st.sidebar.markdown("---")
    st.sidebar.markdown(
        "**数据源**：`outputs/porto_sample1w/sample.jsonl`\n\n"
        "**标签说明**：Porto 原始数据无行程时长真值，时长字段为推断近似值。"
    )

    PAGES[page_name](corpus)


if __name__ == "__main__":
    main()